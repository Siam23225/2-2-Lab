// C++ program for the above approach

#include <bits/stdc++.h>
using namespace std;

// Function to check if the given
// string is a comment or not
void isComment(string line)
{
    for(int i=0;i<line.size();i++)
    {
        if(line[i] == '/' && (line[i+1] == '/' || line[i+1] == '*'))
        {
            cout<<"It's a comment"<<endl;
            break;
        }
        else{
            cout<<"It's not a comment"<<endl;
            break;
        }
    }
}

// Driver Code
int main()
{
	// Given string
	string line ;
    cout<<"Enter your string: ";
    getline(cin,line);
	// Function call to check whether then
	// given string is a comment or not
	isComment(line);

	return 0;
}

