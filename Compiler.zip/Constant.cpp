#include <iostream>
#include <regex>   // For regular expressions
#include <string>
using namespace std;

// Function to check if input is an integer constant
bool isIntegerConstant(const string& s) {
    regex intRegex("[-+]?\\d+");
    return regex_match(s, intRegex);
}

// Function to check if input is a floating-point constant
bool isFloatConstant(const string& s) {
    regex floatRegex("[-+]?\\d*\\.\\d+([eE][-+]?\\d+)?");
    return regex_match(s, floatRegex);
}

// Function to check if input is a character constant
bool isCharConstant(const string& s) {
    return s.length() == 3 && s[0] == '\'' && s[2] == '\'';
}

// Function to check if input is a string constant
bool isStringConstant(const string& s) {
    return s.length() >= 2 && s.front() == '"' && s.back() == '"';
}

// Function to check if input is a boolean constant
bool isBooleanConstant(const string& s) {
    return s == "true" || s == "false";
}

int main() {
    string input;
    cout << "Enter a constant: ";
    getline(cin, input);  // Read the entire input line

    if (isIntegerConstant(input)) {
        cout << "'" << input << "' is an Integer constant." << endl;
    } else if (isFloatConstant(input)) {
        cout << "'" << input << "' is a Floating-point constant." << endl;
    } else if (isCharConstant(input)) {
        cout << "'" << input << "' is a Character constant." << endl;
    } else if (isStringConstant(input)) {
        cout << "'" << input << "' is a String constant." << endl;
    } else if (isBooleanConstant(input)) {
        cout << "'" << input << "' is a Boolean constant." << endl;
    } else {
        cout << "'" << input << "' is not a valid constant." << endl;
    }

    return 0;
}
