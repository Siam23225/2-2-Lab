#include <iostream>
#include <string>
#include <unordered_set>
#include <cctype>

using namespace std;

// List of C++ keywords
unordered_set<string> keywords = {
    "auto", "break", "case", "char", "const", "continue", "default", "do", "double", "else",
    "enum", "extern", "float", "for", "goto", "if", "int", "long", "register", "return",
    "short", "signed", "sizeof", "static", "struct", "switch", "typedef", "union", "unsigned", "void",
    "volatile", "while", "bool", "catch", "class", "delete", "explicit", "false", "friend",
    "inline", "namespace", "new", "operator", "private", "protected", "public", "template",
    "this", "throw", "true", "try", "using", "virtual"
};

bool isValidIdentifier(const string& str) {
    if (!isalpha(str[0]) && str[0] != '_')
        return false;

    for (size_t i = 1; i < str.length(); ++i) {
        if (!isalnum(str[i]) && str[i] != '_')
            return false;
    }

    return true;
}

int main() {
    string input;
    cout << "Enter a string: ";
    cin >> input;

    if (keywords.find(input) != keywords.end())
        cout << input << " is a keyword.\n";
    else if (isValidIdentifier(input))
        cout << input << " is an identifier.\n";
    else
        cout << input << " is neither a keyword nor a valid identifier.\n";

    return 0;
}

