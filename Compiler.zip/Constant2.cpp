#include <iostream>
#include <string>
#include <cctype>

using namespace std;

bool isNumericConstant(const string& str) {
    bool hasDecimal = false;
    for (char ch : str) {
        if (ch == '.') {
            if (hasDecimal) return false;
            hasDecimal = true;
        } else if (!isdigit(ch)) {
            return false;
        }
    }
    return true;
}

bool isCharacterConstant(const string& str) {
    return (str.length() == 3 && str[0] == '\'' && str[2] == '\'');
}

int main() {
    string input;
    cout << "Enter a string to check if it's a constant: ";
    cin >> input;

    if (isNumericConstant(input))
        cout << input << " is a numeric constant.\n";
    else if (isCharacterConstant(input))
        cout << input << " is a character constant.\n";
    else
        cout << input << " is not a recognized constant.\n";

    return 0;
}

