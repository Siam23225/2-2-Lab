#include <iostream>
#include <stack>
#include <map>
#include <vector>
using namespace std;

// Predictive Parsing Table
map<pair<char, char>, string> parsingTable;

// Function to initialize the parsing table
void initializeParsingTable() {
    parsingTable[{'S', 'a'}] = "aXd";
    parsingTable[{'X', 'b'}] = "YZ";
    parsingTable[{'X', 'c'}] = "YZ";
    parsingTable[{'X', 'd'}] = "ε";
    parsingTable[{'Y', 'b'}] = "b";
    parsingTable[{'Y', 'c'}] = "ε";
    parsingTable[{'Z', 'c'}] = "cX";
    parsingTable[{'Z', 'd'}] = "ε";
}

// Function to print the moves of the parser
void printStack(stack<char> s) {
    vector<char> temp;
    while (!s.empty()) {
        temp.push_back(s.top());
        s.pop();
    }
    for (int i = temp.size() - 1; i >= 0; i--) {
        cout << temp[i];
    }
    cout << "\t\t";
}

// LL(1) Parser Implementation
void LL1Parser(string input) {
    stack<char> st;
    st.push('$');  // End marker
    st.push('S');  // Start symbol

    int i = 0;
    cout << "Stack\t\tInput\t\tAction" << endl;

    while (!st.empty()) {
        printStack(st);
        cout << input.substr(i) << "\t\t";

        char top = st.top();
        st.pop();

        if (top == input[i]) {  // Terminal match
            cout << "Match " << top << endl;
            i++;
        } else if (parsingTable.count({top, input[i]})) {  // Non-terminal
            string production = parsingTable[{top, input[i]}];
            cout << top << " → " << production << endl;

            if (production != "ε") {
                for (int j = production.length() - 1; j >= 0; j--) {
                    st.push(production[j]);
                }
            }
        } else {  // Error
            cout << "Error: Invalid string" << endl;
            return;
        }
    }

    if (i == input.length()) {
        cout << "String accepted!" << endl;
    } else {
        cout << "Error: Input not fully parsed" << endl;
    }
}

int main() {
    initializeParsingTable();

    string input;
    cout << "Enter a string: ";
    cin >> input;
    input += '$';  // Append end marker

    LL1Parser(input);

    return 0;
}

