#include <iostream>
#include <string>
#include <cctype>

using namespace std;

bool isValidIdentifier(const string& str) {
    // Check if the first character is a letter or an underscore
    if (!isalpha(str[0]) && str[0] != '_')
        return false;

    // Check if the rest of the characters are alphanumeric or underscores
    for (size_t i = 1; i < str.length(); ++i) {
        if (!isalnum(str[i]) && str[i] != '_')
            return false;
    }

    return true;
}

int main() {
    string input;
    cout << "Enter a string to check if it's an identifier: ";
    cin >> input;

    if (isValidIdentifier(input))
        cout << input << " is a valid identifier.\n";
    else
        cout << input << " is not a valid identifier.\n";

    return 0;
}

