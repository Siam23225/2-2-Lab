#include <iostream>
#include <string>
#include <cctype>
using namespace std;

int i = 0;  // Pointer to current character
string str;  // Input string
int len;     // Length of the input string

// Function declarations for both CFG tasks
bool A();  // A → aXd
bool X();  // X → bbX | bcX | ε
bool Exp();  // <Exp> → <Term> + <Term> | <Term> - <Term> | <Term>
bool Term();  // <Term> → <Factor> * <Factor> | <Factor> / <Factor> | <Factor>
bool Factor();  // <Factor> → ( <Exp> ) | ID | NUM

// Task 1: CFG Implementation for A → aXd, X → bbX | bcX | ε
bool A() {
    if (i < len && str[i] == 'a') {
        i++;  // Consume 'a'
        if (X() && i < len && str[i] == 'd') {
            i++;  // Consume 'd'
            return true;  // Successfully parsed A → aXd
        }
    }
    return false;  // Failed to parse A
}

bool X() {
    if (i >= len || str[i] != 'b') return true;  // X → ε (empty production)

    // Handle X → bbX and X → bcX
    if (i + 1 < len && (str[i + 1] == 'b' || str[i + 1] == 'c')) {
        i += 2;  // Consume 'bb' or 'bc'
        return X();  // Recursive call for X
    }
    return false;  // Failed to parse X
}

// Task 2: CFG Implementation for Simple Arithmetic Expressions
bool Exp() {
    if (Term()) {
        if (i < len && (str[i] == '+' || str[i] == '-')) {
            i++;  // Consume + or -
            return Term();
        }
        return true;  // Single term expression
    }
    return false;  // Invalid expression
}

bool Term() {
    if (Factor()) {
        if (i < len && (str[i] == '*' || str[i] == '/')) {
            i++;  // Consume * or /
            return Factor();
        }
        return true;  // Single factor term
    }
    return false;  // Invalid term
}

bool Factor() {
    if (i < len && str[i] == '(') {
        i++;  // Consume '('
        if (Exp()) {
            if (i < len && str[i] == ')') {
                i++;  // Consume ')'
                return true;
            }
        }
        return false;  // Mismatched parentheses
    }
    if (i < len && isalpha(str[i])) {  // ID → a | b | c | d | e
        i++;
        return true;
    }
    if (i < len && isdigit(str[i])) {  // NUM → 0 | 1 | ... | 9
        i++;
        return true;
    }
    return false;  // Invalid factor
}

int main() {
    int choice;
    cout << "Choose a task:\n";
    cout << "1. Parse string using CFG A → aXd, X → bbX | bcX | ε\n";
    cout << "2. Parse arithmetic expression\n";
    cout << "Enter your choice: ";
    cin >> choice;

    cout << "Enter the input: ";
    cin >> str;
    len = str.length();
    i = 0;  // Reset the pointer for new input

    bool result = false;
    if (choice == 1) {
        result = A();  // Parse using first CFG
    } else if (choice == 2) {
        result = Exp();  // Parse arithmetic expression
    } else {
        cout << "Invalid choice!\n";
        return 1;
    }

    if (result && i == len) {
        cout << "Valid input according to the chosen CFG.\n";
    } else {
        cout << "Invalid input according to the chosen CFG.\n";
    }

    return 0;
}
