#include <iostream>
#include <unordered_set>
#include <stack>
#include <string>
using namespace std;

// Function to check for duplicate identifiers
bool detectDuplicateIdentifiers(const string& code) {
    unordered_set<string> identifiers;  // Store declared identifiers
    bool duplicateFound = false;
    string word;

    for (size_t i = 0; i < code.length(); ++i) {
        // Extract words and skip separators (like spaces, semicolons, etc.)
        if (isalnum(code[i])) {
            word += code[i];
        } else if (!word.empty()) {
            // Check if the word is an identifier already declared
            if (identifiers.find(word) != identifiers.end()) {
                cout << "Error: Duplicate identifier found - '" << word << "'\n";
                duplicateFound = true;
            } else {
                identifiers.insert(word);  // Insert the new identifier
            }
            word.clear();
        }
    }
    return duplicateFound;
}

// Function to detect unbalanced curly braces
bool detectUnbalancedBraces(const string& code) {
    stack<char> braceStack;

    for (char ch : code) {
        if (ch == '{') {
            braceStack.push(ch);  // Push opening brace onto the stack
        } else if (ch == '}') {
            if (braceStack.empty()) {
                cout << "Error: Unbalanced closing brace '}' detected.\n";
                return true;  // Unbalanced brace found
            }
            braceStack.pop();  // Pop matching opening brace
        }
    }

    if (!braceStack.empty()) {
        cout << "Error: Unbalanced opening brace '{' detected.\n";
        return true;
    }

    return false;
}

int main() {
    string code;
    cout << "Enter the code fragment (end with '###' on a new line):\n";

    // Read multi-line input from the user until '###' is entered
    string line;
    while (getline(cin, line) && line != "###") {
        code += line + " ";
    }

    // Check for duplicate identifiers
    bool hasDuplicateIdentifiers = detectDuplicateIdentifiers(code);

    // Check for unbalanced curly braces
    bool hasUnbalancedBraces = detectUnbalancedBraces(code);

    if (!hasDuplicateIdentifiers && !hasUnbalancedBraces) {
        cout << "No syntax errors detected.\n";
    }

    return 0;
}

