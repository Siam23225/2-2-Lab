#include <iostream>
#include <string>

using namespace std;

void removeComments(string& code) {
    bool inSingleLineComment = false;
    bool inMultiLineComment = false;

    string result;

    for (size_t i = 0; i < code.length(); ++i) {
        if (inSingleLineComment && code[i] == '\n') {
            inSingleLineComment = false;
            result += code[i];
        } else if (inMultiLineComment && code[i] == '*' && i + 1 < code.length() && code[i + 1] == '/') {
            inMultiLineComment = false;
            ++i; // skip '/'
        } else if (!inSingleLineComment && !inMultiLineComment) {
            if (code[i] == '/' && i + 1 < code.length() && code[i + 1] == '/') {
                inSingleLineComment = true;
                ++i; // skip second '/'
            } else if (code[i] == '/' && i + 1 < code.length() && code[i + 1] == '*') {
                inMultiLineComment = true;
                ++i; // skip '*'
            } else {
                result += code[i];
            }
        }
    }

    code = result;
}

int main() {
    string code;
    cout << "Enter your C++ code (end with EOF or press Ctrl+D on a new line):\n";
    string line;
    while (getline(cin, line)) {
        code += line + '\n';
    }

    removeComments(code);

    cout << "\nCode after removing comments:\n";
    cout << code;

    return 0;
}

