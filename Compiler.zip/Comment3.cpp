#include <iostream>
#include <string>
#include <vector>  // For storing line numbers
using namespace std;

// Function to find the number of lines containing comments and their line numbers
void countCommentLines(istream& input) {
    string line;
    bool inMultiLineComment = false;
    int commentLineCount = 0;
    int lineNumber = 0;
    vector<int> commentLines;  // Store line numbers with comments

    while (getline(input, line)) {
        lineNumber++;  // Track the current line number

        if (line == "END") break;  // Stop input when 'END' is entered

        bool isCommentLine = false;
        size_t i = 0;

        while (i < line.length()) {
            if (inMultiLineComment) {
                // Check if multi-line comment ends on this line
                size_t end = line.find("*/", i);
                if (end != string::npos) {
                    inMultiLineComment = false;
                    isCommentLine = true;  // Part of the comment is on this line
                    i = end + 2;
                } else {
                    // The entire line is part of a multi-line comment
                    isCommentLine = true;
                    break;
                }
            } else if (line.substr(i, 2) == "/*") {
                // Start of a multi-line comment
                inMultiLineComment = true;
                isCommentLine = true;
                i += 2;
            } else if (line.substr(i, 2) == "//") {
                // Single-line comment detected
                isCommentLine = true;
                break;  // Ignore the rest of the line
            } else {
                ++i;  // Move to the next character
            }
        }

        if (isCommentLine) {
            commentLineCount++;  // Increment the comment line counter
            commentLines.push_back(lineNumber);  // Store the line number
        }
    }

    // Output the total number of lines with comments
    cout << "Total number of lines with comments: " << commentLineCount << endl;

    // Output the line numbers where comments were found
    cout << "Lines with comments: ";
    for (int num : commentLines) {
        cout << num << " ";
    }
    cout << endl;
}

int main() {
    cout << "Enter source code (type 'END' to stop):" << endl;
    countCommentLines(cin);  // Read input from the user
    return 0;
}
