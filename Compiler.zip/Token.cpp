#include <iostream>
#include <string>
#include <vector>
#include <cctype>
#include <unordered_set>

using namespace std;

// List of C++ keywords
unordered_set<string> keywords = {
    "auto", "break", "case", "char", "const", "continue", "default", "do", "double", "else",
    "enum", "extern", "float", "for", "goto", "if", "int", "long", "register", "return",
    "short", "signed", "sizeof", "static", "struct", "switch", "typedef", "union", "unsigned", "void",
    "volatile", "while", "bool", "catch", "class", "delete", "explicit", "false", "friend",
    "inline", "namespace", "new", "operator", "private", "protected", "public", "template",
    "this", "throw", "true", "try", "using", "virtual"
};

// Check if a character is a delimiter (non-alphanumeric character that isn't part of an identifier or literal)
bool isDelimiter(char ch) {
    return isspace(ch) || ispunct(ch);
}

// Check if a string is a keyword
bool isKeyword(const string& str) {
    return keywords.find(str) != keywords.end();
}

// Check if a string is an identifier
bool isIdentifier(const string& str) {
    if (str.empty() || isdigit(str[0]))
        return false;
    for (char ch : str) {
        if (!isalnum(ch) && ch != '_')
            return false;
    }
    return true;
}

// Check if a string is a numeric literal
bool isNumericLiteral(const string& str) {
    if (str.empty()) return false;
    bool hasDecimal = false;
    for (char ch : str) {
        if (ch == '.') {
            if (hasDecimal) return false;
            hasDecimal = true;
        } else if (!isdigit(ch)) {
            return false;
        }
    }
    return true;
}

// Check if a character is an operator
bool isOperator(char ch) {
    return string("+-*/%&|^=<>!").find(ch) != string::npos;
}

// Tokenize the given input string (C++ code)
void tokenize(const string& code) {
    size_t i = 0;
    while (i < code.length()) {
        if (isspace(code[i])) {
            ++i; // Skip whitespace
            continue;
        }

        if (isalpha(code[i]) || code[i] == '_') {
            // Handle keywords and identifiers
            string token;
            while (i < code.length() && (isalnum(code[i]) || code[i] == '_')) {
                token += code[i++];
            }
            if (isKeyword(token)) {
                cout << token << " : Keyword\n";
            } else {
                cout << token << " : Identifier\n";
            }
        } else if (isdigit(code[i])) {
            // Handle numeric literals
            string token;
            while (i < code.length() && (isdigit(code[i]) || code[i] == '.')) {
                token += code[i++];
            }
            if (isNumericLiteral(token)) {
                cout << token << " : Numeric Literal\n";
            } else {
                cout << token << " : Invalid Numeric Literal\n";
            }
        } else if (code[i] == '"' || code[i] == '\'') {
            // Handle string and character literals
            char quote = code[i++];
            string token(1, quote);
            while (i < code.length() && code[i] != quote) {
                token += code[i++];
            }
            if (i < code.length()) {
                token += code[i++]; // Closing quote
            }
            if (quote == '"') {
                cout << token << " : String Literal\n";
            } else {
                cout << token << " : Character Literal\n";
            }
        } else if (isOperator(code[i])) {
            // Handle operators
            string token;
            while (i < code.length() && isOperator(code[i])) {
                token += code[i++];
            }
            cout << token << " : Operator\n";
        } else if (ispunct(code[i])) {
            // Handle punctuation (parentheses, semicolons, etc.)
            cout << code[i] << " : Punctuation\n";
            ++i;
        } else {
            cout << code[i] << " : Unknown Token\n";
            ++i;
        }
    }
}

int main() {
    string code;
    cout << "Enter C++ code (end with EOF or press Ctrl+D on a new line):\n";
    string line;
    while (getline(cin, line)) {
        code += line + '\n';
    }

    cout << "\nTokens:\n";
    tokenize(code);

    return 0;
}

