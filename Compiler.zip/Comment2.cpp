#include <iostream>
#include <string>

using namespace std;

string recognizeCommentType(const string& line) {
    size_t start = 0;
    while (start < line.length() && isspace(line[start])) {
        start++;
    }

    if (line[start] == '/' && line[start + 1] == '/') {
        return "Single-line comment";
    } else if (line[start] == '/' && line[start + 1] == '*') {
        size_t end = line.find("*/", start + 2);
        if (end != string::npos) {
            return "Multi-line comment";
        }
    }
    return "Not a comment";
}

int main() {
    string line;
    cout << "Enter a line of code: ";
    getline(cin, line);

    string commentType = recognizeCommentType(line);
    cout << commentType << endl;

    return 0;
}

