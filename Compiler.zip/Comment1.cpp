#include <iostream>
#include <string>
#include <cctype>  // For isalpha()
using namespace std;

// Function to recognize comments, identify their type, and count letters inside them
void countCommentLetters(istream& input) {
    string line;
    bool inMultiLineComment = false;
    int singleLineLetterCount = 0;
    int multiLineLetterCount = 0;

    while (getline(input, line)) {
        size_t i = 0;

        while (i < line.length()) {
            if (inMultiLineComment) {
                // End of multi-line comment
                size_t end = line.find("*/", i);
                if (end != string::npos) {
                    // Count letters inside the multi-line comment
                    for (size_t j = i; j < end; ++j) {
                        if (isalpha(line[j])) multiLineLetterCount++;
                    }
                    inMultiLineComment = false;
                    i = end + 2;
                } else {
                    // Count letters until the end of the current line
                    for (size_t j = i; j < line.length(); ++j) {
                        if (isalpha(line[j])) multiLineLetterCount++;
                    }
                    break;
                }
            } else if (line.substr(i, 2) == "/*") {
                // Start of a multi-line comment
                inMultiLineComment = true;
                i += 2;
            } else if (line.substr(i, 2) == "//") {
                // Single-line comment: Count letters after "//"
                for (size_t j = i + 2; j < line.length(); ++j) {
                    if (isalpha(line[j])) singleLineLetterCount++;
                }
                break;  // Ignore the rest of the line
            } else {
                ++i;  // Move to the next character
            }
        }
    }

    // Output the letter counts for each type of comment
    cout << "Single-line comment letters: " << singleLineLetterCount << endl;
    cout << "Multi-line comment letters: " << multiLineLetterCount << endl;
}

int main() {
    cout << "Enter source code (type 'END' to stop):" << endl;
    countCommentLetters(cin);  // Use standard input to read the code
    return 0;
}
