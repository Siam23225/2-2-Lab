#include <iostream>
#include <vector>
#include <algorithm>  // Include for std::remove_if
#include <iomanip>    // Include for std::setw
using namespace std;

// Symbol structure
struct Symbol {
    int id;
    string name, type, dataType, scope, value;
};

// Symbol Table class
class SymbolTable {
    vector<Symbol> table;

public:
    void insert(int id) {
        Symbol sym;
        sym.id = id;
        cout << "Enter Name, Type, DataType, Scope, Value (if any): ";
        cin >> sym.name >> sym.type >> sym.dataType >> sym.scope;
        cin.ignore();  // Ignore trailing newline
        getline(cin, sym.value);  // Allow multi-word input for the value
        table.push_back(sym);
    }

    bool update(const string& name, const string& newValue) {
        for (auto& sym : table) {
            if (sym.name == name) {
                sym.value = newValue;
                return true;
            }
        }
        return false;
    }

    bool deleteSymbol(const string& name) {
        auto it = remove_if(table.begin(), table.end(),
                            [&](Symbol& s) { return s.name == name; });
        if (it != table.end()) {
            table.erase(it, table.end());
            return true;
        }
        return false;
    }

    void search(const string& name) const {
        for (const auto& sym : table) {
            if (sym.name == name) {
                displaySymbol(sym);
                return;
            }
        }
        cout << "Symbol '" << name << "' not found.\n";
    }

    void display() const {
        cout << setw(5) << "ID" << setw(10) << "Name" << setw(10) << "Type"
             << setw(10) << "DataType" << setw(10) << "Scope" << setw(10) << "Value\n";
        cout << string(55, '-') << "\n";
        for (const auto& sym : table) displaySymbol(sym);
    }

private:
    void displaySymbol(const Symbol& s) const {
        cout << setw(5) << s.id << setw(10) << s.name << setw(10) << s.type
             << setw(10) << s.dataType << setw(10) << s.scope << setw(10) << s.value << "\n";
    }
};

int main() {
    SymbolTable symTable;
    int choice, id = 1;
    string name, value;

    while (true) {
        cout << "\n1. Insert\n2. Update\n3. Delete\n4. Search\n5. Display\n6. Exit\nChoice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                symTable.insert(id++);
                break;
            case 2:
                cout << "Enter Name to Update: ";
                cin >> name;
                cout << "Enter New Value: ";
                cin.ignore();
                getline(cin, value);  // Allow multi-word input for value
                cout << (symTable.update(name, value) ? "Updated successfully.\n" : "Symbol not found.\n");
                break;
            case 3:
                cout << "Enter Name to Delete: ";
                cin >> name;
                cout << (symTable.deleteSymbol(name) ? "Deleted successfully.\n" : "Symbol not found.\n");
                break;
            case 4:
                cout << "Enter Name to Search: ";
                cin >> name;
                symTable.search(name);
                break;
            case 5:
                symTable.display();
                break;
            case 6:
                return 0;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    }
}
